<?php
/**
 * Plugin Name: Sample Return Plugin
 * Description: A simple plugin that returns specific HTML from flashscore.com via shortcode.
 * Version: 1.1
 * Author: Seth Borey
 */

// === Shortcode Function ===
function show_flashscore_menu_html() {
    $url = 'https://www.livescores.com/football/live/';

    $response = wp_remote_get($url);

    if (is_wp_error($response)) {
        return '<p>Failed to fetch content.</p>';
    }

    $html = wp_remote_retrieve_body($response);

    if (empty($html)) {
        return '<p>No content retrieved.</p>';
    }

    // Load HTML into DOMDocument
    libxml_use_internal_errors(true);
    $doc = new DOMDocument();
    @$doc->loadHTML($html);
    libxml_clear_errors();

    // Use DOMXPath to query the element with class "Le" (Leagues)
    // Use DOMXPath to query the main container and league elements
    $xpath = new DOMXPath($doc);
    $nodes = $xpath->query("//*[contains(concat(' ', normalize-space(@class), ' '), ' Le ')]");
    $leagues = $xpath->query("//*[contains(concat(' ', normalize-space(@class), ' '), ' ec ')]");

    if ($nodes->length === 0 && $leagues->length === 0) {
        return '<p>No content found.</p>';
    }

    $output = '';

    // Add leagues (if any)
    foreach ($leagues as $league) {
        $output .= '<div class="league-block">';
        $output .= $doc->saveHTML($league);
        $output .= '</div>';
    }

    // Add scores/menus (if any)
    foreach ($nodes as $node) {
        $output .= '<div class="score-row">';
        $output .= $doc->saveHTML($node);
        $output .= '</div>';
    }

    // Final return
    return '<div id="flashscore-live">' . $output . '</div>';

}

add_shortcode('flashscore_html', 'show_flashscore_menu_html');


// === AJAX Handler ===
add_action('wp_ajax_get_flashscore_html', 'show_flashscore_menu_html_ajax');
add_action('wp_ajax_nopriv_get_flashscore_html', 'show_flashscore_menu_html_ajax');

function show_flashscore_menu_html_ajax() {
    echo show_flashscore_menu_html();
    wp_die(); // Required for proper AJAX ending
}


// === Enqueue JavaScript ===
add_action('wp_enqueue_scripts', 'flashscore_enqueue_script');

function flashscore_enqueue_assets() {
    wp_enqueue_style(
        'flashscore-style',
        plugin_dir_url(__FILE__) . 'flashscore-style.css'
    );

    wp_enqueue_script(
        'flashscore-auto-refresh',
        plugin_dir_url(__FILE__) . 'auto-refresh.js',
        [], false, true
    );

    wp_localize_script('flashscore-auto-refresh', 'flashscore_ajax_obj', [
        'ajax_url' => admin_url('admin-ajax.php')
    ]);
}