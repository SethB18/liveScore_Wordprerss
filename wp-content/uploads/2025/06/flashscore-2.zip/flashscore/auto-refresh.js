function fetchFlashscoreHTML() {
    fetch(flashscore_ajax_obj.ajax_url + '?action=get_flashscore_html')
        .then(res => res.text())
        .then(html => {
            const container = document.getElementById('flashscore-live');
            if (container) container.innerHTML = html;
        })
        .catch(err => console.error('Fetch error:', err));
}

// Fetch every 3 seconds
setInterval(fetchFlashscoreHTML, 30000);

// Initial fetch when page loads
document.addEventListener('DOMContentLoaded', fetchFlashscoreHTML);
